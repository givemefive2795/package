package com;
import java.io.*;

public class helloword {
    public static void main(String[] args)
    {
        System.out.println("hello world");
    }
}
